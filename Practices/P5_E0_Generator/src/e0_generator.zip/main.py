from e0_generator import E0Generator

e0 = E0Generator()
e0.execute(4)
print(e0.output)
